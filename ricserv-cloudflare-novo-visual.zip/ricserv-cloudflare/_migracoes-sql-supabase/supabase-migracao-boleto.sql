-- Rode isso no SQL Editor do Supabase (projeto do RicServ).
-- Adiciona as colunas que faltam para suportar Boleto além de Pix.
-- Seguro rodar mesmo que a migração anterior (supabase-migracao-pagbank.sql)
-- já tenha sido executada — só adiciona o que ainda não existe.

alter table public.solicitacoes_moedas
  add column if not exists metodo_pagamento text,
  add column if not exists boleto_url text;
