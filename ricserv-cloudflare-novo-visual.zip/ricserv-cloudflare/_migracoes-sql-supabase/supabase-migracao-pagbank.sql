-- Rode isso no SQL Editor do Supabase (projeto do RicServ) antes de publicar.

-- 1) Novas colunas em solicitacoes_moedas, para rastrear o pedido no PagBank
alter table public.solicitacoes_moedas
  add column if not exists referencia_id text unique,
  add column if not exists pagbank_order_id text unique,
  add column if not exists pagbank_charge_id text,
  add column if not exists qr_code_text text,
  add column if not exists qr_code_image_url text,
  add column if not exists expiracao timestamptz,
  add column if not exists pago_em timestamptz;

-- 2) Função que credita moedas de forma atômica (evita condição de corrida
--    se, por algum motivo, o webhook for processado em paralelo).
--    SECURITY DEFINER: roda com privilégio do dono da função, então a
--    Netlify Function (chamando com a service_role key) consegue executá-la
--    mesmo que o profissional não tenha permissão de UPDATE direto na tabela.
create or replace function public.credit_moedas(p_profissional_id uuid, p_quantidade int)
returns void
language sql
security definer
set search_path = public
as $$
  update public.profiles
  set saldo_moedas = saldo_moedas + p_quantidade
  where id = p_profissional_id;
$$;

revoke all on function public.credit_moedas(uuid, int) from public, anon, authenticated;
grant execute on function public.credit_moedas(uuid, int) to service_role;
