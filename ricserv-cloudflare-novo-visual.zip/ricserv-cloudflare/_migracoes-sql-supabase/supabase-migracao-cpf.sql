-- Rode isso no SQL Editor do Supabase (projeto do RicServ).
-- Garante que a tabela profiles tenha a coluna cpf, usada para Boleto e Cartão no PagBank.

alter table public.profiles
  add column if not exists cpf text;

-- IMPORTANTE: se você tem um gatilho (trigger) que copia os dados do
-- cadastro (auth.users.raw_user_meta_data) para a tabela profiles — o
-- típico "handle_new_user()" — confira se ele também copia o campo "cpf".
-- Se não copiar, o CPF de quem se cadastra por e-mail com confirmação
-- ativada (a maioria dos casos) não vai cair no perfil sozinho. Se não
-- souber como ver esse gatilho, me avise que eu te ajudo a checar.
